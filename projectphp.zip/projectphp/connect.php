<?php
$con=new mysqli('localhost','root','','project');

if($con){
       echo "connection successful"."<br>";
}else{
       die(mysqli_error($con));
}
?>